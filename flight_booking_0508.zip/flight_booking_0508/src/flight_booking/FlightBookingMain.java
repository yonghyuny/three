package flight_booking;


public class FlightBookingMain {
	public static void main(String[] args) {

	    	LoginForm loginForm = new LoginForm();

	}
}
